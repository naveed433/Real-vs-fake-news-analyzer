const Database = require('better-sqlite3');
const path = require('path');

const dbFile = path.join(__dirname, '../database.sqlite');
const db = new Database(dbFile);

// Create tables if they don't exist
db.exec(`
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT,
        first_name TEXT,
        last_name TEXT,
        password_hash TEXT NOT NULL,
        password_reset_token TEXT,
        password_reset_expires DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS articles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        title TEXT,
        text TEXT,
        analysis_result TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
    );
`);

// Backfill: add columns if DB was created before (SQLite lacks IF NOT EXISTS for columns)
try {
    const cols = db.prepare(`PRAGMA table_info(users)`).all();
    const names = new Set(cols.map(c => c.name));
    if (!names.has('email')) db.prepare(`ALTER TABLE users ADD COLUMN email TEXT`).run();
    if (!names.has('first_name')) db.prepare(`ALTER TABLE users ADD COLUMN first_name TEXT`).run();
    if (!names.has('last_name')) db.prepare(`ALTER TABLE users ADD COLUMN last_name TEXT`).run();
    if (!names.has('password_reset_token')) db.prepare(`ALTER TABLE users ADD COLUMN password_reset_token TEXT`).run();
    if (!names.has('password_reset_expires')) db.prepare(`ALTER TABLE users ADD COLUMN password_reset_expires DATETIME`).run();
} catch (e) {
    console.error('users table migration check failed:', e.message);
}

module.exports = db;