console.log('📦 Loading dependencies...');
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');
const dotenv = require('dotenv');
const path = require('path');
const session = require('express-session');
const passport = require('passport');

console.log('📁 Loading routes...');
const authRoutes = require('./routes/auth');
const apiRoutes = require('./routes/api');

console.log('⚙️  Loading environment variables...');
dotenv.config();
console.log(`   PORT: ${process.env.PORT || 4001}`);

const app = express();

// Error handling
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
});

process.on('unhandledRejection', (err) => {
  console.error('Unhandled Rejection:', err);
});

// Configure CORS: allow a list of origins via CORS_ORIGINS or single CORS_ORIGIN env var
const rawCorsList = process.env.CORS_ORIGINS || process.env.CORS_ORIGIN || '';
const allowedOrigins = rawCorsList.split(',').map(s => s.trim()).filter(Boolean);
// Always allow localhost during development
if (!allowedOrigins.includes('http://localhost:3000')) allowedOrigins.push('http://localhost:3000');

app.use(cors({
  origin: function(origin, callback) {
    // Allow non-browser tools (no origin) like curl/postman
    if (!origin) return callback(null, true);
    if (allowedOrigins.includes(origin)) return callback(null, true);
    console.warn('Blocked CORS origin:', origin);
    return callback(new Error('Not allowed by CORS'));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Simple session for passport (OAuth flows)
app.use(session({ secret: process.env.JWT_SECRET || 'change_this', resave: false, saveUninitialized: true }));
app.use(passport.initialize());
app.use(passport.session());

// Mount routes
app.use('/auth', authRoutes);
app.use('/api', apiRoutes);

// Optional static serving of frontend if deployed together
if (process.env.STATIC_DIR) {
  const staticDir = path.isAbsolute(process.env.STATIC_DIR)
    ? process.env.STATIC_DIR
    : path.join(__dirname, '..', process.env.STATIC_DIR);
  app.use(express.static(staticDir));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api') || req.path.startsWith('/auth')) return next();
    res.sendFile(path.join(staticDir, 'index.html'));
  });
}

// Health
app.get('/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 4001;

// Start server with error handling
console.log(`\n🚀 Starting server on port ${PORT}...\n`);

const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`═══════════════════════════════════════════════════════`);
  console.log(`🚀 BACKEND SERVER IS RUNNING!`);
  console.log(`═══════════════════════════════════════════════════════`);
  console.log(`   URL: http://localhost:${PORT}`);
  console.log(`   Health: http://localhost:${PORT}/health`);
  console.log(`   Status: ✅ READY`);
  console.log(`═══════════════════════════════════════════════════════\n`);
  
  // Non-fatal checks
  try {
    const { supabase } = require('./supabase');
    if (supabase) console.log('   ✓ Supabase client available');
    else console.log('   ⚠️  Supabase not configured — continuing without it');
  } catch (e) {
    console.error('   ✗ Supabase load error:', e.message || e);
  }
  
  console.log('🔑 Checking API keys...');
  if (process.env.DEEPSEEK_API_KEY) {
    console.log('   ✓ Deepseek API configured');
  } else {
    console.log('   ✓ Deepseek API: not configured');
  }
  if (process.env.GEMINI_API_KEY) {
    console.log('   ✓ Gemini API configured');
  }
  
  console.log(`\n✅ ✅ ✅ SERVER IS READY! ✅ ✅ ✅`);
  console.log(`\n📱 Frontend should connect to: http://localhost:${PORT}`);
  console.log(`\n⚠️  KEEP THIS TERMINAL OPEN!\n`);
  console.log(`═══════════════════════════════════════════════════════\n`);
});

// Handle server errors
server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\n❌ ERROR: Port ${PORT} is already in use!`);
    console.error(`   Please close the other application using port ${PORT} or change PORT in .env\n`);
    process.exit(1);
  } else {
    console.error('Server error:', err);
    process.exit(1);
  }
});
