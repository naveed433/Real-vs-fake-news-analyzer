const bcrypt = require('bcryptjs');
const { supabase, supabaseAdmin, mirrorUser } = require('./supabase');

function isPasswordStrong(password) {
    const hasLower = /[a-z]/.test(password);
    const hasUpper = /[A-Z]/.test(password);
    const hasDigit = /\d/.test(password);
    const hasSymbol = /[^A-Za-z0-9]/.test(password);
    return password && password.length >= 8 && hasLower && hasUpper && hasDigit && hasSymbol;
}

async function registerUser({ username, email, firstName, lastName, password }) {
    try {
        if (!username || !email || !password) {
            return { success: false, message: 'username, email, and password are required.' };
        }
        username = String(username).toLowerCase();
        if (!isPasswordStrong(password)) {
            return { success: false, message: 'Password must be 8+ chars with upper, lower, number, and symbol.' };
        }

        const client = supabaseAdmin || supabase;
        if (!client) {
            // If no Supabase configured, create a dummy user record locally in SQLite (if desired)
            return { success: false, message: 'Registration requires Supabase to be configured in this deployment.' };
        }

        const { data: existingUsers, error: existingErr } = await client
            .from('users')
            .select('id')
            .eq('username', username)
            .limit(1);
        if (existingErr) throw existingErr;
        if (existingUsers && existingUsers.length > 0) {
            return { success: false, message: 'Username already exists.' };
        }

        const hash = await bcrypt.hash(password, 10);
        const now = new Date().toISOString();

        const { data, error } = await client
            .from('users')
            .insert([{ username, email, first_name: firstName || null, last_name: lastName || null, password_hash: hash, created_at: now }])
            .select()
            .single();

        if (error) throw error;

        try {
            await mirrorUser({ id: data.id, username: data.username, email: data.email, first_name: data.first_name, last_name: data.last_name, created_at: data.created_at });
        } catch (supabaseErr) {
            console.warn('Supabase mirror after insert failed:', supabaseErr.message || supabaseErr);
        }

        return {
            success: true,
            userId: data.id,
            username: data.username,
            profile: {
                id: data.id,
                username: data.username,
                email: data.email,
                firstName: data.first_name,
                lastName: data.last_name
            }
        };
    } catch (err) {
        console.error('registerUser error', err);
        return { success: false, message: err.message || 'Database error' };
    }
}

async function loginUser(username, password) {
    try {
        username = String(username).toLowerCase();

        const client = supabaseAdmin || supabase;
        if (!client) return { success: false, message: 'Supabase not configured' };

        const { data: users, error: fetchErr } = await client
            .from('users')
            .select('id, username, email, first_name, last_name, password_hash')
            .eq('username', username)
            .limit(1);
        if (fetchErr) throw fetchErr;
        const user = users && users[0];

        if (!user) return { success: false, message: 'Invalid username or password.' };

        const match = await bcrypt.compare(password, user.password_hash);
        if (!match) return { success: false, message: 'Invalid username or password.' };

        const now = new Date().toISOString();
        const { error: updateErr } = await client.from('users').update({ last_login: now }).eq('id', user.id);
        if (updateErr) console.warn('Failed to update last_login in Supabase:', updateErr.message || updateErr);

        try {
            await mirrorUser({ ...user, last_login: now });
        } catch (supabaseErr) {
            console.warn('Supabase mirror error during login:', supabaseErr.message || supabaseErr);
        }

        return {
            success: true,
            userId: user.id,
            profile: {
                id: user.id,
                username: user.username,
                email: user.email,
                firstName: user.first_name,
                lastName: user.last_name
            }
        };
    } catch (err) {
        console.error('loginUser error', err);
        return { success: false, message: err.message || 'Database error' };
    }
}

function createResetToken(userId) {
    const token = Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
    const expires = new Date(Date.now() + 1000 * 60 * 30).toISOString();
    const client = supabaseAdmin || supabase;
    if (!client) return token;
    client.from('users').update({ password_reset_token: token, password_reset_expires: expires }).eq('id', userId).then(({ error }) => {
        if (error) console.error('Failed to set reset token in Supabase:', error.message || error);
    });
    return token;
}

async function getUserByEmail(email) {
    try {
    const client = supabaseAdmin || supabase;
    if (!client) return null;
    const { data, error } = await client.from('users').select('*').eq('email', email).limit(1);
        if (error) throw error;
        return data && data[0] ? data[0] : null;
    } catch (e) {
        console.error('getUserByEmail error:', e.message || e);
        return null;
    }
}

async function getUserByResetToken(token) {
    try {
    const client = supabaseAdmin || supabase;
    if (!client) return null;
    const { data, error } = await client.from('users').select('*').eq('password_reset_token', token).limit(1);
        if (error) throw error;
        const user = data && data[0] ? data[0] : null;
        if (!user) return null;
        if (user.password_reset_expires && new Date(user.password_reset_expires) < new Date()) return null;
        return user;
    } catch (e) {
        console.error('getUserByResetToken error:', e.message || e);
        return null;
    }
}

async function setNewPassword(userId, newPassword) {
    try {
        if (!isPasswordStrong(newPassword)) {
            return { success: false, message: 'Weak password' };
        }
        const hash = await bcrypt.hash(newPassword, 10);
    const client = supabaseAdmin || supabase;
    if (!client) return { success: false, message: 'Supabase not configured' };
    const { error } = await client.from('users').update({ password_hash: hash, password_reset_token: null, password_reset_expires: null }).eq('id', userId);
        if (error) throw error;
        return { success: true };
    } catch (e) {
        console.error('setNewPassword error:', e.message || e);
        return { success: false, message: e.message || 'Database error' };
    }
}

module.exports = { registerUser, loginUser, isPasswordStrong, createResetToken, getUserByEmail, getUserByResetToken, setNewPassword };