Deployable backend bundle

Instructions:

1. Copy the entire `deploy_backend` folder to your server or Hostinger account.
2. Create a `.env` file in the `deploy_backend` folder using `.env.example` and set your values.
3. Install dependencies:
   npm install --production
4. Start the server:
   npm start

Notes:
- If you don't configure Supabase credentials, the backend will continue running but Supabase-related features will be disabled.
- Ensure `CORS_ORIGIN` matches the frontend domain (include https://).
- For production, use a process manager such as PM2: `pm2 start src/index.js --name rvf-backend`.