const { createClient } = require('@supabase/supabase-js');
const dotenv = require('dotenv');
dotenv.config();

if (!process.env.SUPABASE_URL || !process.env.SUPABASE_ANON_KEY) {
  console.warn('⚠️ Supabase credentials not provided. Supabase functionality will be disabled.');
  // Provide no-op fallback clients to avoid runtime crashes
  const noop = () => ({
    from: () => ({ insert: async () => ({ data: null }), upsert: async () => ({ data: null }) }),
    auth: {}
  });
  module.exports = { supabase: null, supabaseAdmin: null, mirrorUser: async () => null, mirrorAnalysis: async () => null, recordUserSession: async () => null, recordSessionDataMapping: async () => null, recordWebsiteAnalytics: async () => null, recordUserHistory: async () => null, recordUserClaims: async () => null };
  return;
}

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY,
  {
    auth: {
      autoRefreshToken: true,
      persistSession: false,
      detectSessionInUrl: false
    },
    db: {
      schema: 'public'
    }
  }
);

let supabaseAdmin = null;
if (process.env.SUPABASE_SERVICE_ROLE_KEY) {
  supabaseAdmin = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY,
    {
      auth: { persistSession: false, detectSessionInUrl: false },
      db: { schema: 'public' }
    }
  );
}

async function mirrorUser(user) {
  if (!supabase) return null;
  try {
    const supabaseUser = {
      id: user.id,
      username: user.username,
      email: user.email || null,
      first_name: user.first_name || null,
      last_name: user.last_name || null,
      created_at: user.created_at || new Date().toISOString(),
      provider: user.provider || 'local',
      provider_id: user.provider_id || null,
      last_login: new Date().toISOString()
    };

    const client = supabaseAdmin || supabase;
    const { data, error } = await client.from('users').upsert(supabaseUser, {
      onConflict: 'id',
      returning: true
    });

    if (error) throw error;
    console.log('✓ User mirrored to Supabase:', data[0]?.username);
    return data[0];
  } catch (e) {
    console.error('Supabase mirrorUser failed:', e.message);
    return null;
  }
}

async function mirrorAnalysis(analysisRow) {
  if (!supabase) return null;
  try {
    const client = supabaseAdmin || supabase;
    await client.from('articles').insert({
      user_id: analysisRow.user_id || null,
      title: analysisRow.title,
      text: analysisRow.text,
      analysis_result: analysisRow.analysis_result,
      created_at: analysisRow.created_at || new Date().toISOString()
    });
  } catch (e) {
    console.error('Supabase mirrorAnalysis failed:', e.message);
  }
}

async function recordUserSession(event) {
  if (!supabase) return null;
  try {
    const client = supabaseAdmin || supabase;
    await client.from('user_sessions').insert({
      user_id: event.user_id || null,
      username: event.username || null,
      is_guest: !!event.is_guest,
      action: event.action,
      token_prefix: event.token ? String(event.token).slice(0, 12) : null,
      created_at: new Date().toISOString()
    });
  } catch (e) { console.error('Supabase recordUserSession failed:', e.message); }
}

async function recordSessionDataMapping(map) {
  if (!supabase) return null;
  try {
    const client = supabaseAdmin || supabase;
    await client.from('session_data_mapping').insert({
      user_id: map.user_id || null,
      session_token_prefix: map.token ? String(map.token).slice(0, 12) : null,
      metadata: map.metadata || null,
      created_at: new Date().toISOString()
    });
  } catch (e) { console.error('Supabase recordSessionDataMapping failed:', e.message); }
}

async function recordWebsiteAnalytics(evt) {
  if (!supabase) return null;
  try {
    const client = supabaseAdmin || supabase;
    await client.from('website_analytics').insert({
      user_id: evt.user_id || null,
      event_name: evt.event_name,
      details: evt.details || null,
      created_at: new Date().toISOString()
    });
  } catch (e) { console.error('Supabase recordWebsiteAnalytics failed:', e.message); }
}

async function recordUserHistory(hist) {
  if (!supabase) return null;
  try {
    const client = supabaseAdmin || supabase;
    await client.from('user_history').insert({
      user_id: hist.user_id || null,
      action: hist.action,
      data: hist.data || null,
      created_at: new Date().toISOString()
    });
  } catch (e) { console.error('Supabase recordUserHistory failed:', e.message); }
}

async function recordUserClaims(userId, claims) {
  if (!supabase) return null;
  if (!Array.isArray(claims) || claims.length === 0) return null;
  try {
    const rows = claims.map(c => ({
      user_id: userId || null,
      claim: c.claim || null,
      source: c.source || null,
      verdict: c.verdict || null,
      url: c.url || null,
      created_at: new Date().toISOString()
    }));
    const client = supabaseAdmin || supabase;
    await client.from('user_claims').insert(rows);
  } catch (e) { console.error('Supabase recordUserClaims failed:', e.message); }
}

module.exports = { supabase, supabaseAdmin, mirrorUser, mirrorAnalysis, recordUserSession, recordSessionDataMapping, recordWebsiteAnalytics, recordUserHistory, recordUserClaims };