const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
const { registerUser, loginUser, createResetToken, getUserByEmail, getUserByResetToken, setNewPassword } = require('../auth');
const { recordUserSession, recordSessionDataMapping, supabase, supabaseAdmin } = require('../supabase');
dotenv.config();

const JWT_SECRET = process.env.JWT_SECRET || 'change_this_to_a_strong_secret';

function generateToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' });
}

// POST /auth/signup
router.post('/signup', async (req, res) => {
  try {
    const { username, email, firstName, lastName, password } = req.body || {};
    if (!username || !email || !password) return res.status(400).json({ error: 'username, email and password required' });
    const result = await registerUser({ username, email, firstName, lastName, password });
    if (!result.success) return res.status(400).json({ error: result.message || 'Signup failed' });
    const token = generateToken({ id: result.userId, username: result.username });
    recordUserSession({ user_id: result.userId, username: result.username, action: 'signup', is_guest: false, token }).catch(()=>{});
    recordSessionDataMapping({ user_id: result.userId, token, metadata: { type: 'signup' } }).catch(()=>{});
    res.json({ ok: true, token, userId: result.userId, username: result.username });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /auth/login
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ error: 'username and password required' });
    const result = await loginUser(username, password);
    if (!result.success) return res.status(401).json({ error: result.message || 'Login failed' });
    const finalUsername = (result.profile && result.profile.username) || username;
    const token = generateToken({ id: result.userId, username: finalUsername });
    recordUserSession({ user_id: result.userId, username: finalUsername, action: 'login', is_guest: false, token }).catch(()=>{});
    recordSessionDataMapping({ user_id: result.userId, token, metadata: { type: 'login' } }).catch(()=>{});
    res.json({ ok: true, token, userId: result.userId, profile: result.profile });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /auth/guest - creates a temporary guest account and returns token
router.post('/guest', async (req, res) => {
  try {
    const rand = Math.random().toString(36).substring(2, 9);
    const username = `guest_${rand}`;
    const password = Math.random().toString(36);
    const result = await registerUser({ username, email: `${username}@guest.local`, firstName: 'Guest', lastName: rand, password });
    if (!result.success) return res.status(500).json({ error: result.message || 'Could not create guest' });
    const token = generateToken({ id: result.userId, username, guest: true });
    recordUserSession({ user_id: result.userId, username, action: 'guest_login', is_guest: true, token }).catch(()=>{});
    recordSessionDataMapping({ user_id: result.userId, token, metadata: { type: 'guest' } }).catch(()=>{});
    res.json({ ok: true, token, userId: result.userId, username });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /auth/profile
router.get('/profile', async (req, res) => {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return res.status(401).json({ error: 'Missing token' });
  const token = auth.slice(7);
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const userId = payload.id;
    if (!userId) return res.status(401).json({ error: 'Invalid token payload' });
    const client = supabaseAdmin || supabase;
    if (!client) return res.status(500).json({ error: 'Supabase not configured' });
    const { data, error } = await client.from('users').select('id,username,email,first_name,last_name,provider,provider_id,created_at,avatar_url,account_type,is_verified,profile_complete,status,theme,language,email_notifications').eq('id', userId).limit(1).single();
    if (error) return res.status(500).json({ error: error.message || error });
    const profile = data || { id: userId, username: payload.username };
    res.json({ ok: true, profile });
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
});

// PUT /auth/profile - update profile fields
router.put('/profile', async (req, res) => {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return res.status(401).json({ error: 'Missing token' });
  const token = auth.slice(7);
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const userId = payload.id;
    if (!userId) return res.status(401).json({ error: 'Invalid token payload' });
    const allowed = ['username','first_name','last_name','avatar_url','theme','language','email_notifications','status','account_type'];
    const updates = {};
    for (const key of allowed) if (key in req.body) updates[key] = req.body[key];

    if (updates.username) {
      const client = supabaseAdmin || supabase;
      if (!client) return res.status(500).json({ error: 'Supabase not configured' });
      const { data: existing, error: e } = await client.from('users').select('id').eq('username', String(updates.username).toLowerCase()).limit(1);
      if (e) return res.status(500).json({ error: e.message || e });
      if (existing && existing.length > 0 && existing[0].id !== userId) return res.status(400).json({ error: 'Username already taken' });
      updates.username = String(updates.username).toLowerCase();
    }

    const client = supabaseAdmin || supabase;
    if (!client) return res.status(500).json({ error: 'Supabase not configured' });
    const { data, error } = await client.from('users').update(updates).eq('id', userId).select().single();
    if (error) return res.status(500).json({ error: error.message || error });
    res.json({ ok: true, profile: data });
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
});

const bcrypt = require('bcryptjs');
router.post('/change-password', async (req, res) => {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return res.status(401).json({ error: 'Missing token' });
  const token = auth.slice(7);
  const { oldPassword, newPassword } = req.body || {};
  if (!oldPassword || !newPassword) return res.status(400).json({ error: 'oldPassword and newPassword required' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const userId = payload.id;
    const client = supabaseAdmin || supabase;
    if (!client) return res.status(500).json({ error: 'Supabase not configured' });
    const { data, error } = await client.from('users').select('id,password_hash').eq('id', userId).limit(1).single();
    if (error) return res.status(500).json({ error: error.message || error });
    const user = data;
    if (!user) return res.status(404).json({ error: 'User not found' });
    const match = await bcrypt.compare(oldPassword, user.password_hash);
    if (!match) return res.status(401).json({ error: 'Old password incorrect' });
    const hash = await bcrypt.hash(newPassword, 10);
    const { error: upErr } = await client.from('users').update({ password_hash: hash }).eq('id', userId);
    if (upErr) return res.status(500).json({ error: upErr.message || upErr });
    res.json({ ok: true });
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
});

router.get('/accounts', async (req, res) => {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return res.status(401).json({ error: 'Missing token' });
  const token = auth.slice(7);
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const userId = payload.id;
    const client = supabaseAdmin || supabase;
    if (!client) return res.status(500).json({ error: 'Supabase not configured' });
    const { data: me } = await client.from('users').select('email').eq('id', userId).limit(1).single();
    if (!me || !me.email) return res.json({ ok: true, accounts: [] });
    const { data: accounts, error } = await client.from('users').select('id,username,email,first_name,last_name,avatar_url').eq('email', me.email);
    if (error) return res.status(500).json({ error: error.message || error });
    res.json({ ok: true, accounts });
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
});

router.post('/switch-account', async (req, res) => {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return res.status(401).json({ error: 'Missing token' });
  const token = auth.slice(7);
  const { targetUserId } = req.body || {};
  if (!targetUserId) return res.status(400).json({ error: 'targetUserId required' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const userId = payload.id;
    const client = supabaseAdmin || supabase;
    if (!client) return res.status(500).json({ error: 'Supabase not configured' });
    const { data: me } = await client.from('users').select('email').eq('id', userId).limit(1).single();
    const { data: target } = await client.from('users').select('email,username').eq('id', targetUserId).limit(1).single();
    if (!me || !target || me.email !== target.email) return res.status(403).json({ error: 'Not allowed to switch to that account' });
    const newToken = jwt.sign({ id: targetUserId, username: target.username }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ ok: true, token: newToken, userId: targetUserId, username: target.username });
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
});

router.post('/forgot', async (req, res) => {
  try {
    const { email } = req.body || {};
    if (!email) return res.status(400).json({ error: 'email required' });
    const user = getUserByEmail(email);
    if (!user) return res.json({ ok: true });
    const token = createResetToken(user.id);
    if (process.env.EMAIL_SERVICE) {
      try {
        await sendResetEmail(email, token);
      } catch (emailErr) {
        console.error('Failed to send reset email:', emailErr);
      }
    }
    res.json({ ok: true, token });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/reset', async (req, res) => {
  try {
    const { token, password } = req.body || {};
    if (!token || !password) return res.status(400).json({ error: 'token and password required' });
    const user = getUserByResetToken(token);
    if (!user) return res.status(400).json({ error: 'Invalid or expired token' });
    const result = await setNewPassword(user.id, password);
    if (!result.success) return res.status(400).json({ error: result.message || 'Could not set password' });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;